# searchgoat Quick Start Guide

**Query Cribl Search. Get DataFrames.**

---

## What You Need

- Python 3.10 or later
- Cribl Cloud account with API credentials
- macOS or Linux (Windows: use WSL)

---

## Setup (5 minutes)

### 1. Download and extract

Unzip `searchgoat-quickstart.zip` and open a terminal in that folder.

### 2. Run setup

```bash
chmod +x setup.sh
./setup.sh
```

The script will:
- Create a Python virtual environment
- Install searchgoat from GitHub
- Prompt you for your Cribl credentials
- Save them securely to `.env`

### 3. Find your credentials

| Credential | Where to find it |
|------------|------------------|
| **Client ID** | Cribl Cloud → ⚙️ → Organization Settings → API Credentials |
| **Client Secret** | Shown once when you create the credential — copy it immediately |
| **Org ID** | From your URL: `https://{workspace}-{org_id}.cribl.cloud` |
| **Workspace** | From your URL: `https://{workspace}-{org_id}.cribl.cloud` |

**Example URL:** `https://main-abc123xyz.cribl.cloud`  
→ workspace = `main`, org_id = `abc123xyz`

---

## Run Your First Query

```bash
source venv/bin/activate
python query.py
```

Edit `query.py` to change the dataset, time range, or query.

---

## Query Examples

**Basic query:**
```python
df = client.query('cribl dataset="cribl_logs" | limit 100', earliest="-1h")
```

**Filter:**
```python
df = client.query('cribl dataset="cribl_logs" | where level="ERROR"', earliest="-24h")
```

**Aggregate:**
```python
df = client.query('cribl dataset="cribl_logs" | stats count() by host', earliest="-24h")
```

**Longer time range:**
```python
df = client.query('cribl dataset="cribl_logs" | limit 10000', earliest="-7d", timeout=600)
```

---

## Save Results

```python
# CSV (universal)
df.to_csv("results.csv", index=False)

# Parquet (faster, smaller)
df.to_parquet("results.parquet", index=False)
```

---

## Troubleshooting

| Error | Solution |
|-------|----------|
| `ValidationError: Field required` | Check your `.env` file has all four variables |
| `AuthenticationError: 401` | Client ID or secret is wrong — create new credentials in Cribl |
| `QuerySyntaxError` | Dataset name doesn't exist — check spelling in Cribl Search UI |
| `JobTimeoutError` | Query took too long — add `\| limit N` or narrow time range |

---

## File Structure

```
searchgoat-quickstart/
├── setup.sh      # Run once to configure
├── query.py      # Edit and run your queries
├── .env          # Your credentials (DO NOT commit to git)
├── venv/         # Python environment (created by setup.sh)
└── README.md     # This guide
```

---

## Next Steps

- Edit `query.py` to query your datasets
- Use the DataFrame in pandas for analysis
- Build scripts that run on a schedule
- Check out [searchgoat on GitHub](https://github.com/JeremiahJRRoss/searchgoat) for full documentation

---

## License

Apache 2.0

---

*Part of the hackish.pub project family. 🐐*
