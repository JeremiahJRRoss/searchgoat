#!/usr/bin/env python3
"""
searchgoat Query Example

Queries Cribl Search and returns a pandas DataFrame.
Edit the DATASET and QUERY variables below to customize.
"""

from dotenv import load_dotenv
load_dotenv()  # Load credentials from .env

from searchgoat import SearchClient

# ════════════════════════════════════════════════════════════════
# CONFIGURATION - Edit these values
# ════════════════════════════════════════════════════════════════

DATASET = "cribl_logs"        # Your dataset name
TIME_RANGE = "-1h"            # How far back to search
LIMIT = 10                    # Max records to return

# Build query (edit as needed)
QUERY = f'cribl dataset="{DATASET}" | limit {LIMIT}'

# ════════════════════════════════════════════════════════════════
# RUN QUERY
# ════════════════════════════════════════════════════════════════

def main():
    print(f"🐐 searchgoat")
    print(f"   Dataset: {DATASET}")
    print(f"   Time range: {TIME_RANGE}")
    print(f"   Query: {QUERY}")
    print("")
    
    # Initialize client (reads CRIBL_* from environment)
    client = SearchClient()
    
    # Execute query
    print("Querying Cribl Search...")
    df = client.query(QUERY, earliest=TIME_RANGE)
    
    print(f"✓ Retrieved {len(df)} records")
    print(f"✓ Columns: {list(df.columns)}")
    print("")
    
    # Display results
    print(df)
    
    # Optional: Save to file
    # df.to_csv("results.csv", index=False)
    # df.to_parquet("results.parquet", index=False)
    
    return df


if __name__ == "__main__":
    df = main()
